# TalentMind AI Final Submission

## Installation
1. Install backend dependencies: `pip install -r requirements.txt`
2. Install frontend dependencies: `npm install`

## Setup
1. Run `python manage.py migrate` in `backend/`.
2. Seed sample data: `python scripts/seed_demo.py`
3. Set `GEMINI_API_KEY` if available for LLM recruiter signals.

## Run Commands
- Backend: `python manage.py runserver`
- Frontend: `npm run dev`
- Generate sample artifacts: `python scripts/generate_submission_package.py`

## API Endpoints
- POST /api/analyze-jd/
- POST /api/rank/
- GET /api/candidates/
- GET /api/rankings/
- GET /api/rankings/export/?job_id=<id>&format=submission

## Project Structure
- backend/: Django backend and ranking services
- frontend/: React + Tailwind dashboard
- docs/: architecture and presentation notes
- exports/: generated CSV and JSON outputs
- FINAL_SUBMISSION/: final packaged submission artifacts

## Screenshots
- screenshots/dashboard_home.png
- screenshots/dashboard_ranked.png
