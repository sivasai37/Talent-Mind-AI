# Submission Checklist

- [x] Source code included under source_code/
- [x] TalentMind_AI_Presentation.pptx included
- [x] TalentMind_AI_Presentation.pdf included
- [x] ranked_candidates.csv included
- [x] sample_ranked_output.csv included
- [x] sample_explanations.json included
- [x] screenshots included
- [x] README.md included
- [x] ZIP archive created
