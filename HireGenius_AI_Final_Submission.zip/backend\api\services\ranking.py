"""
ranking.py — HireGenius AI Core Ranking Engine

Features:
- Dynamic role-aware ranking weights
- Multi-agent evaluation (5 specialized agents)
- Candidate Potential Score
- Skill Gap Prediction with learning paths
- Caching for FAISS index
- Full explainability output
"""
from __future__ import annotations

import threading
from typing import List, Dict, Any, Optional

import numpy as np
from django.conf import settings

from ..models import Candidate, CandidateEmbedding
from .embeddings import get_engine
from .vector_store import rebuild_store, get_store
from .skill_engine import compute_skill_fit
from .experience_engine import compute_experience_fit
from .behavioral_engine import compute_recruitability_score
from .multi_agent import run_multi_agent_evaluation
from .jd_understanding import analyze_job_description

# ---------------------------------------------------------------------------
# Index caching — rebuild only once per process (invalidate on demand)
# ---------------------------------------------------------------------------
_index_lock = threading.Lock()
_index_built = False
_index_candidate_count = 0


def _candidate_text(candidate: Candidate) -> str:
    parts = [candidate.full_name, candidate.profile_text, candidate.skills or ""]
    if candidate.github_url:
        parts.append(candidate.github_url)
    if candidate.certifications:
        parts.append(candidate.certifications)
    if candidate.education_level:
        parts.append(candidate.education_level)
    return " \n ".join([p for p in parts if p])


def build_index(force: bool = False) -> None:
    """Compute embeddings for all candidates and rebuild the in-memory FAISS store.
    
    Uses caching to avoid rebuilding on every request. Set force=True to invalidate.
    """
    global _index_built, _index_candidate_count

    with _index_lock:
        current_count = Candidate.objects.count()

        if not force and _index_built and current_count == _index_candidate_count:
            return  # cache hit

        engine = get_engine()
        candidates = list(Candidate.objects.all())
        if not candidates:
            return

        texts = [_candidate_text(c) for c in candidates]
        vecs = engine.encode(texts)
        id_vec_pairs = []
        for c, v in zip(candidates, vecs):
            CandidateEmbedding.objects.update_or_create(candidate=c, defaults={"vector": v.tolist()})
            id_vec_pairs.append((c.id, v))
        rebuild_store(id_vec_pairs)
        _index_built = True
        _index_candidate_count = current_count


def invalidate_index() -> None:
    """Force rebuild on next request."""
    global _index_built
    with _index_lock:
        _index_built = False


# ---------------------------------------------------------------------------
# Role type detection
# ---------------------------------------------------------------------------

_ROLE_TYPE_KEYWORDS = {
    "backend": [
        "backend", "back-end", "server", "api", "django", "flask", "fastapi",
        "node", "java", "golang", "microservices", "rest", "graphql", "database",
        "postgresql", "mysql", "redis", "kafka",
    ],
    "frontend": [
        "frontend", "front-end", "react", "vue", "angular", "javascript", "typescript",
        "css", "html", "ui", "ux", "design system", "web developer", "nextjs",
    ],
    "leadership": [
        "manager", "director", "head of", "vp", "vice president", "team lead",
        "engineering manager", "cto", "cpo", "principal", "staff engineer",
        "people manager", "leadership", "strategy",
    ],
    "research": [
        "research", "scientist", "phd", "machine learning", "deep learning",
        "nlp", "computer vision", "ai research", "reinforcement learning",
        "paper", "publication", "llm", "foundation model",
    ],
    "data": [
        "data scientist", "data engineer", "analytics", "sql", "etl",
        "data pipeline", "spark", "hadoop", "bigquery", "tableau", "power bi",
        "data analyst", "bi developer",
    ],
    "design": [
        "designer", "ux", "ui", "product design", "figma", "sketch",
        "user research", "design thinking", "interaction design", "visual design",
    ],
}


def detect_role_type(job_struct: dict, title: str = "") -> str:
    """Detect the role type from job structure and title for dynamic weight selection."""
    combined = (
        (title or "").lower() + " " +
        (job_struct.get("title", "")).lower() + " " +
        " ".join(job_struct.get("required_skills", [])).lower() + " " +
        " ".join(job_struct.get("preferred_skills", [])).lower()
    )

    scores = {}
    for role, keywords in _ROLE_TYPE_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in combined)
        scores[role] = score

    best_role = max(scores, key=scores.get)
    if scores[best_role] == 0:
        return "general"
    return best_role


def get_role_weights(role_type: str) -> dict:
    """Get ranking weights for a specific role type."""
    role_weights = getattr(settings, "ROLE_WEIGHTS", {})
    return role_weights.get(role_type, getattr(settings, "RANKING_WEIGHTS", {
        "semantic": 0.30,
        "skill": 0.30,
        "experience": 0.20,
        "recruitability": 0.10,
        "llm": 0.10,
    }))


# ---------------------------------------------------------------------------
# Main search & ranking
# ---------------------------------------------------------------------------

def search_job(
    job_text: str,
    job_required_skills: Optional[str] = None,
    min_experience: Optional[float] = None,
    top_k: int = 10,
    job_struct: Optional[dict] = None,
    title: str = "",
) -> List[Dict[str, Any]]:
    """Return ranked candidate list with full explainability, multi-agent scores, and potential scores.

    Accepts either raw parameters or a `job_struct` as produced by `analyze_job_description`.
    """
    engine = get_engine()
    store = get_store()
    qvec = engine.encode_one(job_text)
    sem_results = store.search(qvec, top_k=top_k)

    candidates = {
        c.id: c
        for c in Candidate.objects.prefetch_related("jobs").filter(
            id__in=[i for i, _ in sem_results]
        )
    }

    # normalize inputs from job_struct when provided
    if job_struct is not None:
        req_skills = job_struct.get("required_skills", [])
        try:
            min_exp = float(job_struct.get("experience_years") or 0.0)
        except Exception:
            min_exp = 0.0
    else:
        req_skills = (
            []
            if job_required_skills is None
            else [s.strip() for s in job_required_skills.split(",") if s.strip()]
        )
        min_exp = 0.0 if min_experience is None else float(min_experience)

    # Detect role type and get dynamic weights
    role_type = detect_role_type(job_struct or {}, title=title)
    weights = get_role_weights(role_type)

    results = []
    for cid, sem_score in sem_results:
        cand = candidates.get(cid)
        if cand is None:
            continue

        # Semantic score (cosine mapped to 0-100)
        sem_pct = max(0.0, float(sem_score)) * 100.0

        # Skill engine
        skill_pct, skill_details = compute_skill_fit(req_skills, cand.skills or "")

        # Experience engine
        career_history = [
            {
                "title": j.title,
                "company": j.company,
                "start_date": j.start_date.isoformat() if j.start_date else None,
                "end_date": j.end_date.isoformat() if j.end_date else None,
                "description": j.description,
            }
            for j in cand.jobs.all()
        ]
        exp_res = compute_experience_fit(
            min_exp,
            cand.years_experience,
            career_history=career_history,
            job_industry=(job_struct or {}).get("industry", ""),
        )
        exp_pct = float(exp_res.get("score", 0.0))

        # Behavioral / recruitability engine
        rec_res = compute_recruitability_score(cand)
        rec_pct = float(rec_res.get("score", 0.0))

        scores = {
            "semantic_score": sem_pct,
            "skill_score": skill_pct,
            "experience_score": exp_pct,
            "recruitability_score": rec_pct,
        }

        # Multi-agent evaluation (5 agents)
        agent_results = run_multi_agent_evaluation(
            job_struct=job_struct or {"title": title},
            candidate=cand,
            scores=scores,
            skill_details=skill_details if isinstance(skill_details, dict) else {},
            exp_details=exp_res.get("details", {}),
            rec_details=rec_res.get("details", {}),
        )

        # Extract LLM / committee score
        llm_pct = float(agent_results.get("committee_score", 0.0))
        if llm_pct <= 1.0:
            llm_pct *= 100.0

        # Weighted final score using role-aware weights
        final = (
            sem_pct * weights.get("semantic", 0.30)
            + skill_pct * weights.get("skill", 0.30)
            + exp_pct * weights.get("experience", 0.20)
            + rec_pct * weights.get("recruitability", 0.10)
            + llm_pct * weights.get("llm", 0.10)
        )

        # Collect all strengths and weaknesses
        strengths = []
        weaknesses = []

        if skill_pct >= 70:
            strengths.append("Strong skill alignment with required stack")
        elif skill_pct >= 40:
            strengths.append("Partial skill match — can ramp up")
        else:
            weaknesses.append("Significant skill gap vs. requirements")

        if exp_pct >= 70:
            strengths.append("Experience well aligned with role demands")
        elif exp_pct >= 45:
            weaknesses.append("Experience partially meets requirements")
        else:
            weaknesses.append("Experience below required threshold")

        if rec_pct >= 60:
            strengths.append("Strong recruitability and engagement signals")
        else:
            weaknesses.append("Low recruiter engagement signals")

        # Merge agent strengths/weaknesses
        strengths.extend(agent_results.get("skill_strengths", []))
        strengths.extend(agent_results.get("experience_strengths", []))
        strengths.extend(agent_results.get("behavioral_strengths", []))
        weaknesses.extend(agent_results.get("skill_gaps", []))
        weaknesses.extend(agent_results.get("experience_gaps", []))
        weaknesses.extend(agent_results.get("behavioral_concerns", []))

        # Deduplicate
        seen = set()
        strengths = [x for x in strengths if not (x in seen or seen.add(x))]
        seen = set()
        weaknesses = [x for x in weaknesses if not (x in seen or seen.add(x))]

        results.append({
            "candidate_id": cid,
            "full_name": cand.full_name,
            "role_type": role_type,
            "weights_used": weights,
            # Core scores
            "semantic_score": float(sem_pct),
            "skill_score": float(skill_pct),
            "experience_score": float(exp_pct),
            "recruitability_score": float(rec_pct),
            "llm_score": float(llm_pct),
            "final_score": float(final),
            # Multi-agent enriched fields
            "potential_score": float(agent_results.get("potential_score", min(100, final * 1.1))),
            "confidence_score": float(agent_results.get("confidence_score", 70.0)),
            "risk_level": agent_results.get("risk_level", "medium"),
            # Explainability
            "strengths": strengths[:6],
            "weaknesses": weaknesses[:6],
            "missing_skills": agent_results.get("missing_skills", skill_details.get("missing", [])),
            "learning_path": agent_results.get("learning_path", []),
            "interview_questions": agent_results.get("interview_questions", []),
            "future_roles": agent_results.get("future_roles", []),
            "growth_forecast": agent_results.get("growth_forecast", {}),
            "salary_fit": agent_results.get("salary_fit", {}),
            "why_selected": agent_results.get("why_selected", ""),
            "why_rejected": agent_results.get("why_rejected", ""),
            "role_fit_analysis": agent_results.get("role_fit_analysis", ""),
            "recruiter_recommendation": agent_results.get("final_recommendation", "Moderate Fit"),
            "recruiter_summary": agent_results.get("recruiter_summary", agent_results.get("hiring_committee_summary", "")),
            "career_trajectory": agent_results.get("career_trajectory", "unknown"),
            "growth_potential_summary": agent_results.get("growth_potential_summary", ""),
            # Full agent payload
            "skill_details": skill_details,
            "experience_details": exp_res.get("details", {}),
            "recruitability_details": rec_res.get("details", {}),
            "agent_results": agent_results,
            # Score explanations
            "semantic_explanation": f"Semantic similarity {sem_pct:.1f}/100 — how closely the profile matches the job description conceptually.",
            "skill_explanation": (
                skill_details.get("explanation") or
                f"Skill match: {len(skill_details.get('matched', []))} of "
                f"{len(skill_details.get('matched', [])) + len(skill_details.get('missing', []))} required skills found."
            ),
            "experience_explanation": (
                exp_res.get("summary") or
                f"Experience score {exp_pct:.1f}/100 — based on years, career growth, stability, and industry alignment."
            ),
            "behavioral_explanation": (
                rec_res.get("summary") or
                f"Recruitability score {rec_pct:.1f}/100 — based on response rate, interview completion, and engagement."
            ),
        })

    # Sort by final score descending
    results.sort(key=lambda r: r["final_score"], reverse=True)
    return results
